
function Descricao(props) {
    return (
      <p>{props.descricao}</p>
    );
  }
  
  export default Descricao;
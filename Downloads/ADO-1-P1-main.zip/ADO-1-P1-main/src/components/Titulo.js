import Texto from "./Texto";

function Titulo(props) {
  return (
    <p>{props.titulo}</p>
  );
}

export default Titulo;
